﻿# Independent shortcut creator; requires no DarkZombie process or admin rights.
$ErrorActionPreference = 'Stop'
try {
    $exe = Join-Path $PSScriptRoot 'DarkZombie.exe'
    $ico = Join-Path $PSScriptRoot 'DarkZombie.ico'
    if (!(Test-Path -LiteralPath $exe)) { throw 'DarkZombie.exe not found next to this script.' }
    $desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
    if (!(Test-Path -LiteralPath $desktop)) { throw 'Desktop location unavailable.' }
    $path = Join-Path $desktop 'DarkZombie.lnk'
    $ws = New-Object -ComObject WScript.Shell
    try {
        $link = $ws.CreateShortcut($path)
        $link.TargetPath = $exe
        $link.WorkingDirectory = $PSScriptRoot
        $link.Description = 'DarkZombie | KushZombie Software - Display Dimmer'
        $link.IconLocation = ("{0},0" -f $(if (Test-Path -LiteralPath $ico) { $ico } else { $exe }))
        $link.Save()
    } finally {
        if ($ws) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($ws) }
    }
    Write-Host ('Created: ' + $path) -ForegroundColor Green
    Write-Host 'Keep the extracted DarkZombie folder in place. The shortcut points to DarkZombie.exe there.'
} catch {
    Write-Host ('Shortcut creation failed: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
