# DarkZombie-only emergency reset.
# Kills only PowerShell processes whose command line specifically names DarkZombie.ps1.
# Windows immediately removes the overlay windows when their process exits.
$ErrorActionPreference = 'Stop'
$targets = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" |
    Where-Object {
        $_.ProcessId -ne $PID -and
        $_.CommandLine -match '(?i)DarkZombie[.]ps1([" ]|$)'
    })
if ($targets.Count -eq 0) {
    Write-Host 'DarkZombie is not running. No processes changed.'
} else {
    foreach ($p in $targets) {
        Write-Host ('Stopping only DarkZombie process PID {0}' -f $p.ProcessId)
        Stop-Process -Id $p.ProcessId -Force
    }
    Write-Host 'Dimming overlays removed. Other PowerShell/Aubum processes untouched.'
}
