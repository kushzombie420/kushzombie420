@echo off
setlocal
cd /d "%~dp0"
start "DarkZombie" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0DarkZombie.ps1"
exit /b 0
