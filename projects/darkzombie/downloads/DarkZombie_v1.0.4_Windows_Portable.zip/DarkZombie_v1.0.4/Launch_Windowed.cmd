@echo off
setlocal
cd /d "%~dp0"
start "DarkZombie (Windowed)" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0DarkZombie.ps1" -Windowed
exit /b 0
