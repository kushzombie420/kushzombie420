﻿DARKZOMBIE v1.0.4  |  KUSHZOMBIE SOFTWARE
=======================================
A new fullscreen, touchscreen-friendly software dimmer for Windows.
This is an independent app, not a modified copy of Dimmer.exe.

FAST START
----------
1. Extract the WHOLE ZIP into a normal folder, such as Desktop\DarkZombie.
   Leave DarkZombie.exe and DarkZombie.ps1 together in the same folder.
2. Double-click DarkZombie.exe. The main interface starts in fullscreen.
3. Move a large slider to dim that display, or use CHILL/NIGHT/ZOMBIE presets.
4. To put the controls on the Steam Deck display (or any second screen):
   - Press F11 to switch to a movable window.
   - Drag the window onto the target display, then press F11 again.
   - You can also begin with Launch_Windowed.cmd to move it first.
5. Click the "_" button to hide to the system tray.
   Double-click the tray icon to reopen; right-click it to reset or exit.

WHAT IT DOES
------------
- Detects Windows monitors automatically at launch; RESCAN if needed.
- Touch-friendly 0-85% DIM sliders, independently adjustable per display.
- Aubum-matched deep-black UI with neon purple + zombie green KushZombie theme.
- True borderless fullscreen on whichever display holds the window.
- F11: fullscreen/windowed. Escape: leave fullscreen.
- Ctrl+0 (while app window has focus): reset all dimming to zero.
- CLEAR, CHILL (20%), NIGHT (40%), ZOMBIE (60%) presets for all displays.
- SAVE FAVORITE / LOAD FAVORITE stores your per-monitor configuration.
- Automatic saved levels between sessions.
- System tray controls to show, RESET ALL DIMMING, or exit.
- Single-instance protection: opening the app again reopens the existing UI.
- Emergency_Reset.cmd can stop ONLY the DarkZombie process if something hangs.

IMPORTANT LIMITATIONS
---------------------
This is software dimming through click-through black overlays. It does NOT
change the physical brightness/backlight of an internal laptop screen or TV.
Some exclusive-fullscreen games, protected content, capture software,
HDR pipelines, and special display drivers may appear above the overlay.
Borderless-window games tend to behave better. Multimonitor/mixed-DPI setups
may need a manual RESCAN after adding/rearranging displays.

MAXIMUM DIM IS 85%, intentionally. You can always RESET ALL DIMMING via the
tray menu or the Emergency_Reset.cmd fallback. Windows destroys the overlay
windows when the process exits, even if you have to force-stop it.

THIS IS A PORTABLE APP
----------------------
Requirements: Windows 10/11 x64, built-in Windows PowerShell 5.1, and .NET
Framework with WPF/Windows Forms (normally already included on Windows).
No separate Python, Node, installers, Sunshine, or third-party runtime.
No administrator privileges required. Nothing connects to the internet.

DarkZombie.exe is a small Windows x64 launcher for the included PowerShell
WPF GUI. The main source is the readable DarkZombie.ps1. If you prefer to
skip the unsigned EXE, use Launch_DarkZombie.cmd directly.

Because this is a personal unsigned build, Windows Defender/SmartScreen may
warn about an unrecognized publisher. Inspect the supplied source before
running anything if you prefer. Do not run random internet copies.

SETTINGS & DEBUGGING
--------------------
Settings: %LOCALAPPDATA%\DarkZombie\settings.json
Error log: %LOCALAPPDATA%\DarkZombie\error.log
If the GUI fails to launch, double-click Launch_Debug.cmd to see errors.
If you've got the original Dimmer running, close it first to avoid stacking
two different dimming utilities on the same monitors.

To uninstall: choose Exit from DarkZombie's tray menu, then delete the folder.
The local settings folder may be deleted separately if you want a clean slate.

BUILD STATUS
------------
The Windows x64 launcher was compiled and its PE headers/imports checked.
The XML markup for the GUI and monitor cards passed static parsing checks.
Live Windows GUI and real monitor/Steam Deck runtime behavior have NOT been
tested in this Linux-based build environment; user acceptance testing is
still required. This is a second-pass v1.0.4 build, still not a claimed field-tested release.

Created for KushZombie Software. No original Dimmer files are included.

V1.0.2 FIX (2026-11-07)
-------------------------
This release corrects the duplicate here-string terminators accidentally
introduced in v1.0.1, which caused a PowerShell parse failure at startup.
It also changes the cards to two equal, stretched columns and increases
card height to fit each slider, percent labels, and +/- buttons cleanly.
The 1.0.0 working release remains a safe rollback. Settings are compatible.


PREMIUM REPAIR NOTES (v1.0.4)
-----------------------------
- Fixed invalid WPF template trigger targets against DropShadowEffect objects.
  Hover glows now replace the named Border's Effect as a complete value.
- Preserved the uploaded Premium black/purple/green styling and display controls.
- Saved PowerShell source with a UTF-8 BOM for Windows PowerShell 5.1.
- Added a clear notice when an older DarkZombie instance is already running.
- Added Diagnose_DarkZombie.cmd for readable PowerShell/XAML preflight results.

IMPORTANT: First exit any older DarkZombie from the Windows tray, then
extract this full ZIP to a fresh folder and launch DarkZombie.exe.
If the window still does not open, run Diagnose_DarkZombie.cmd.
This package passed Linux-side static checks only. Actual WPF runtime
acceptance on Windows remains pending.

BRANDING / SHORTCUT UPDATE (v1.0.4)
-------------------------------------
- The DZ icon is the actual DarkZombie application/shortcut/tray image.
- CREATE SHORTCUT appears in the app header; tray menu also has it.
- Create_Desktop_Shortcut.cmd creates the same shortcut without opening the GUI.
- The launcher now embeds the DZ icon in its Windows executable resources.
- DarkZombie requests its own Windows taskbar identity (AppUserModelID), but
  PowerShell.exe remains the hosting process and can still appear in Task Manager.
- A desktop shortcut points to the EXE in its extracted folder; moving the
  folder later will break the shortcut until it is recreated.
- No admin rights and no automatic registry/system changes.
- As before, exiting old DarkZombie tray copies before testing a new one is required.

WINDOWS RUNTIME STATUS
----------------------
This v1.0.4 update has passed structural/static tests in a Linux build
environment. Native Windows rendering, icon/taskbar identity, and shortcut
creation still require user acceptance testing.
