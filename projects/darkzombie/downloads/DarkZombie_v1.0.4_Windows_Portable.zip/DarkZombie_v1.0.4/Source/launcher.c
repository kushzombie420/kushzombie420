/* DarkZombie launch stub. Windows GUI-subsystem x64 PE, no runtime dependency.
 * Launches the accompanying DarkZombie.ps1 in a hidden PowerShell 5.1 process.
 * The actual interface and dimming implementation are in DarkZombie.ps1.
 */
typedef unsigned short wchar_t;
typedef void* HANDLE;
typedef void* HINSTANCE;
typedef void* HWND;
__declspec(dllimport) unsigned long __stdcall GetModuleFileNameW(HINSTANCE,wchar_t*,unsigned long);
__declspec(dllimport) HINSTANCE __stdcall ShellExecuteW(HWND,const wchar_t*,const wchar_t*,const wchar_t*,const wchar_t*,int);
__declspec(dllimport) int __stdcall MessageBoxW(HWND,const wchar_t*,const wchar_t*,unsigned int);

static int copy_text(wchar_t* out, int capacity, const wchar_t* str, int offset) {
    while (*str && offset < capacity - 1) out[offset++] = *str++;
    out[offset] = 0;
    return offset;
}

static wchar_t modulePath[2048];
static wchar_t folder[2048];
static wchar_t scriptPath[2048];
static wchar_t command[4096];

int WinMain(void) {
    unsigned long len = GetModuleFileNameW((HINSTANCE)0, modulePath, 2048);
    if (len < 3 || len >= 2047) {
        MessageBoxW((HWND)0, L"Unable to find DarkZombie's application folder.", L"DarkZombie", 0x10);
        return 1;
    }
    int i, end = 0;
    for (i = 0; i < (int)len; i++) if (modulePath[i] == L'\\' || modulePath[i] == L'/') end = i + 1;
    if (end <= 0) return 1;
    for (i = 0; i < end; i++) folder[i] = modulePath[i];
    folder[end] = 0;
    int p = copy_text(scriptPath, 2048, folder, 0);
    copy_text(scriptPath, 2048, L"DarkZombie.ps1", p);
    p = copy_text(command, 4096, L"-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"", 0);
    p = copy_text(command, 4096, scriptPath, p);
    copy_text(command, 4096, L"\"", p);
    HINSTANCE result = ShellExecuteW((HWND)0, L"open", L"powershell.exe", command, folder, 0);
    if ((unsigned long long)result <= 32ULL) {
        MessageBoxW((HWND)0,
            L"Could not start Windows PowerShell. Try Launch_Debug.cmd from the same folder.",
            L"DarkZombie - launch failed", 0x10);
        return 2;
    }
    return 0;
}
