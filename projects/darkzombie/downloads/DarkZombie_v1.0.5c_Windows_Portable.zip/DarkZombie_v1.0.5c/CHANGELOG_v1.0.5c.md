# DarkZombie v1.0.5c - Polished startup repair candidate

Built on **the actual v1.0.5 visual-polish source**, not the stripped-down v1.0.5b fallback.

- **Preserved:** all v1.0.5 visual design, logo image, purple/green palette, layout, presets, tray UI, high-resolution asset files, slider, fine controls and touch-friendly interface.
- **Startup correction:** repackaged the **byte-identical v1.0.4 executable** rather than the resource-mutated v1.0.5 executable; external v1.0.5 icon and PNG stay included.
- **WPF defensive paths:** optional FocusVisualStyle fallback if polished main window XAML fails; accepted v1.0.4 card fallback only if the new per-monitor custom template throws during runtime loading. Both failures log their original exception for diagnosis.
- **Visibility:** included `Launch_Visible_Startup.cmd` to show startup errors, rather than hiding the only evidence.
- **Unchanged:** overlay WinForms engine, settings path, favorite persistence, emergency reset, singleton mutex, monitor enumeration, desktop shortcut scripts, and network-free architecture.

**Limit:** Could not execute Windows WPF here. ZIP, source markers, XML structures, and executable integrity can be verified statically; live Windows startup needs the owner's confirmation. No claim of a verified fix is made.
