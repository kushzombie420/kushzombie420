@echo off
setlocal
cd /d "%~dp0"
echo Starting DarkZombie v1.0.5c with visible startup errors...
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0DarkZombie.ps1"
if errorlevel 1 (
  echo.
  echo Startup failed. Error log: %LOCALAPPDATA%\DarkZombie\error.log
  pause
)
