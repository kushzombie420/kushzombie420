DARKZOMBIE v1.0.5c | POLISHED STARTUP REPAIR (WINDOWS TEST BUILD)
KushZombie Software

This retains the original v1.0.5 polished WPF interface, logo, dark/purple/green
palette, touch controls, fine buttons, presets and multi-display software dimming.

To run:
  1. Exit any existing DarkZombie through its Windows tray icon first.
     Both versions deliberately share one single-instance lock.
  2. Extract the ENTIRE ZIP to a NEW folder, without overwriting v1.0.4.
  3. Double-click DarkZombie.exe in that folder.

If the window does not open, use Launch_Visible_Startup.cmd ONCE from the same folder.
The application writes any fatal detail to %LOCALAPPDATA%\DarkZombie\error.log.

Version and source details:
- EXE is byte-identical to the user-accepted v1.0.4 executable for safer startup.
- The branded icon file and PNG are from the original v1.0.5 polish ZIP.
- Main UI source retains the polished v1.0.5 interface and behavior.
- Two defensive WPF-XAML fallback paths cover optional visual-template failures.
- Reset, overlay engine, storage, shortcuts, and per-screen controls are retained.
- Source (DarkZombie.ps1) is included. No installation or administrator needed.
- Emergency_Reset.cmd can remove dimming if it ever becomes stuck.

STATUS: Windows startup NOT independently verified here. This is a repair
candidate, NOT the already accepted v1.0.4 release. Do not delete v1.0.4.
