@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create_Desktop_Shortcut.ps1"
if errorlevel 1 (
  echo.
  echo Could not create desktop shortcut. See the error above.
)
pause
