param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$clock = Join-Path $root 'KushZombie_Clock_v2.1_DarkZombie.html'
$icon  = Join-Path $root 'KushZombie_Clock.ico'
if (-not (Test-Path -LiteralPath $clock)) { throw 'Clock HTML not found beside this script. Extract the entire ZIP first.' }
if (-not (Test-Path -LiteralPath $icon)) { throw 'Clock icon not found beside this script. Extract the entire ZIP first.' }
$desktop = [Environment]::GetFolderPath('DesktopDirectory')
if ([string]::IsNullOrWhiteSpace($desktop) -or -not (Test-Path -LiteralPath $desktop)) { throw 'Desktop folder not found.' }
$shortcutPath = Join-Path $desktop 'KushZombie Clock.lnk'
$shell = New-Object -ComObject WScript.Shell
try {
  $link = $shell.CreateShortcut($shortcutPath)
  $link.TargetPath = $clock
  $link.WorkingDirectory = $root
  $link.IconLocation = ('{0},0' -f $icon)
  $link.Description = 'KushZombie Clock v2.1 - DarkZombie Edition (offline clock)'
  $link.Save()
} finally {
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell)
}
Write-Host "Created desktop shortcut: $shortcutPath"
Write-Host 'Keep the extracted folder in its current location or recreate the shortcut after moving it.'
