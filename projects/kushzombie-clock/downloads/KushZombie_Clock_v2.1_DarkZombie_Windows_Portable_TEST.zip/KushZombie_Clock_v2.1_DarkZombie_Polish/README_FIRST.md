# KushZombie Clock v2.1 · DarkZombie Edition

**Portable, offline desktop clock with a DarkZombie-inspired black/charcoal, purple, and zombie-green theme.**

## Run on Windows
1. Extract the **entire** ZIP to a permanent folder.
2. Double-click `START_CLOCK.cmd`, or open `KushZombie_Clock_v2.1_DarkZombie.html` in a modern browser.
3. To add its branded logo to your desktop, run `Create_Desktop_Shortcut.cmd` once. It makes a `.lnk` that opens the local HTML with your default browser. **No installation required.**

The clock always uses the PC's current local date and time, even after sleep/resume. Internet access is not needed. No trackers, accounts, or remote requests.

## Existing v2 features retained
- Live local 12/24-hour digital clock and full calendar date
- Seconds indicator, subtle ambient glow, dim overlay
- Fullscreen toggle and responsive layout
- Auto-hiding buttons and saved browser-local preferences
- Keyboard: `T` format, `S` seconds, `A` ambient, `D` dim, `F` fullscreen, `H` controls

## What changed in v2.1
- DarkZombie-inspired charcoal clock surface, deep purple framing, zombie-green accent lighting
- Dark glass number panel masks the fixed digits on the background art, so **only the live time** is displayed
- Larger, rounded touch controls and subdued ambient art
- Embedded browser favicon, matching PNG/SVG icon, Windows `.ico`, optional desktop shortcut helper

## Verification / limitations
- Original JavaScript clock engine and browser storage key retained.
- Linux Chromium offline UI/interaction tests completed. Windows desktop shortcut and cross-browser behavior require owner testing.
- Not a native Windows EXE. Opens as a local HTML page in the default web browser.
- 1280x800 artwork is adapted to wider/narrower viewports, which may show small bars or scale down controls.

**Credit:** KushZombie concept/creative direction and acceptance; AI-assisted implementation/polish. Art is part of the existing KushZombie v2 clock asset; no original background art has been replaced. No third-party service affiliation.
