@echo off
start "" "%~dp0KushZombie_Clock_v2.1_DarkZombie.html"
